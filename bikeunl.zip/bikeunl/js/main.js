// sell with us

var currentTab = 0;
document.addEventListener("DOMContentLoaded", function(event) {


showTab(currentTab);

});

function showTab(n) {
var x = document.getElementsByClassName("tab");
x[n].style.display = "block";
if (n == 0) {
document.getElementById("prevBtn").style.display = "none";
} else {
document.getElementById("prevBtn").style.display = "inline";
}
if (n == (x.length - 1)) {
document.getElementById("nextBtn").innerHTML = "Submit";
} else {
document.getElementById("nextBtn").innerHTML = "Next";
}
fixStepIndicator(n)
}

function nextPrev(n) {
var x = document.getElementsByClassName("tab");
if (n == 1 && !validateForm()) return false;
x[currentTab].style.display = "none";
currentTab = currentTab + n;
if (currentTab >= x.length) {
// document.getElementById("regForm").submit();
// return false;
//alert("sdf");
document.getElementById("nextprevious").style.display = "none";
document.getElementById("all-steps").style.display = "none";
document.getElementById("register").style.display = "none";
document.getElementById("text-message").style.display = "block";




}
showTab(currentTab);
}

function validateForm() {
var x, y, i, valid = true;
x = document.getElementsByClassName("tab");
y = x[currentTab].getElementsByTagName("input");
for (i = 0; i < y.length; i++) { if (y[i].value=="" ) { y[i].className +=" invalid" ; valid=false; } } if (valid) { document.getElementsByClassName("step")[currentTab].className +=" finish" ; } return valid; } function fixStepIndicator(n) { var i, x=document.getElementsByClassName("step"); for (i=0; i < x.length; i++) { x[i].className=x[i].className.replace(" active", "" ); } x[n].className +=" active" ; }



// end of sell with us



// navbar scroll top fixed
 var nav = document.getElementById('nav-menu');

 window.onscroll = function () {

   if(window.pageYOffset > 10){

    nav.style.position = "fixed";
    nav.style.background="#004283";
    nav.style.zIndex="200";
    nav.style.top = 0;
    nav.style.width="100%";
    // nav.style.padding="13px";

  }
  else{
            nav.style.position = 'relative'; //fixed
            nav.style.top = 100;

            // nav.style.padding="20px";
            nav.style.background="#004283";  //linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.5))

          }
        }
        // scroll top fixed ends

   $('.mobileproduct-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    autoplay:true,
    autoplayHoverPause: true,
    dots:false,
    autoplayTimeout:4000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:4
        }
    }
})


   // product carousel

    $('.brand-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    autoplay:true,
    autoplayHoverPause: true,
    dots:false,
    autoplayTimeout:1000,
    responsive:{
        0:{
            items:3
        },
        600:{
            items:5
        },
        1000:{
            items:6
        }
    }
})



           





// product carousel

    $('.product-carousel').owlCarousel({
    loop:true,
    margin:30,
    nav:false,
    autoplay:true,
    autoplayHoverPause: true,
    dots:false,
    autoplayTimeout:4000,
    responsive:{
        0:{
            items:3
        },
        600:{
            items:3
        },
        1000:{
            items:3
        }
    }
})

// end of horizontal carousel


// product carousel

    $('.specific-brand').owlCarousel({
    loop:true,
    margin:30,
    nav:false,
    autoplay:true,
    autoplayHoverPause: true,
    dots:false,
    autoplayTimeout:4000,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:2
        },
        1000:{
            items:4
        }
    }
})

// end of horizontal carousel


function wishList(){
    var list = document.getElementById("toast");
  list.classList.add("show");
  list.innerHTML = '<i class="far fa-heart wish"></i> Product added to List';
  setTimeout(function(){
    list.classList.remove("show");
  },3000);
}

function addCart(){
      var cart = document.getElementById("toast-cart");
  cart.classList.add("show");
  cart.innerHTML = '<i class="fas fa-shopping-cart cart"></i> Product added to cart';
  setTimeout(function(){
    cart.classList.remove("show");
  }, 3000);
}


 function openmenu()
      {
          document.getElementById("side-menu").style.display="block";
          document.getElementById("menu-btn").style.display="none";
          document.getElementById("close-btn").style.display="block";
      }
      function closemenu()
      {
          document.getElementById("side-menu").style.display="none";
          document.getElementById("menu-btn").style.display="block";
          document.getElementById("close-btn").style.display="none";
      }



// product count


/////////////////// product +/-
$(document).ready(function() {
  $('.num-in span').click(function () {
      var $input = $(this).parents('.num-block').find('input.in-num');
    if($(this).hasClass('minus')) {
      var count = parseFloat($input.val()) - 1;
      count = count < 1 ? 1 : count;
      if (count < 2) {
        $(this).addClass('dis');
      }
      else {
        $(this).removeClass('dis');
      }
      $input.val(count);
    }
    else {
      var count = parseFloat($input.val()) + 1
      $input.val(count);
      if (count > 1) {
        $(this).parents('.num-block').find(('.minus')).removeClass('dis');
      }
    }
    
    $input.change();
    return false;
  });
  
});
// product +/-



// navbar collapse

   $(document).ready(function() {
$(window).resize(function(){
  if ($(window).width() >= 980){  

      $(".navbar .dropdown-toggle").hover(function () {
         $(this).parent().toggleClass("show");
         $(this).parent().find(".dropdown-menu").toggleClass("show"); 
       });

      $( ".navbar .dropdown-menu" ).mouseleave(function() {
        $(this).removeClass("show");  
      });
  
  } 
});  
  

});



   // home product carousel


// $(document).ready(function() {

//   $("#owl-home-brand").owlCarousel({

   
//     items : 6,
//     itemsDesktop : [1199,6],
//     itemsDesktopSmall : [979,4],
//     stopOnHover: true,
//     pagination: true,
//     itemsTablet : [899,1],
//     itemsMobile : [599,1],
//     autoPlay: 3000

// });


//   $("#owl-home-product").owlCarousel({

//     items : 2,
//     itemsDesktop : [1199,2],
//     itemsDesktopSmall : [979,2],
//     stopOnHover: true,
//     pagination: true,
//     itemsTablet : [899,1],
//     itemsMobile : [599,1],
//     autoPlay: 3000

// });

//   $("#owl-healthcare-carousel").owlCarousel({

    
//     items : 1,
//     itemsDesktop : [1199,1],
//     itemsDesktopSmall : [979,1],
//     stopOnHover: true,
//     pagination: true,
//     itemsTablet : [899,1],
//     itemsMobile : [599,1],
//     autoPlay: 3000

// });

//   $("#owl-diagonostic-carousel").owlCarousel({

 
//     items : 1,
//     itemsDesktop : [1199,1],
//     itemsDesktopSmall : [979,1],
//     stopOnHover: true,
//     pagination: true,
//     itemsTablet : [899,1],
//     itemsMobile : [599,1],
//     autoPlay: 3000

// });

  

// });





   // end of home product carousel

























// float to top

var btn = $('#float-button');

$(window).scroll(function() {
  if ($(window).scrollTop() > 300) {
    btn.addClass('show');
  } else {
    btn.removeClass('show');
  }
});

btn.on('click', function(e) {
  e.preventDefault();
  $('html, body').animate({scrollTop:0}, '300');
});




// category-sidebar

  $('#category-tabs li a').click(function(){
    $(this).next('ul').slideToggle('500');
    $(this).find('i').toggleClass('fa-minus fa-plus ')
});


  









// add to cart modal


// $(document).ready(function() {  
//   $('#cartModal').modal('show');
// });


// compare

$(function(){
$('[data-filter="trigger"]').on("change", function() {
    var t = $(this).find("option:selected").val().toLowerCase();

  $('[data-filter="target"]').css("display", "none"); 
  $("#" + t).css("display", "table-row-group"); 
  if(t == "all") {
    $('[data-filter="target"]').css("display", "table-row-group")
  }
  $(this).css("display", "block"); 
});
})


$('.add-to-cart').on('click', function () {
        var cart = $('.shopping-cart');
        var imgtodrag = $(this).parent('.product-image1').find("img").eq(0);
        if (imgtodrag) {
            var imgclone = imgtodrag.clone()
                .offset({
                top: imgtodrag.offset().top,
                left: imgtodrag.offset().left
            })
                .css({
                'opacity': '0.8',
                    'position': 'absolute',
                    'height': '150px',
                    'width': '150px',
                    'z-index': '100'
            })
                .appendTo($('body'))
                .animate({
                'top': cart.offset().top + 10,
                    'left': cart.offset().left + 10,
                    'width': 75,
                    'height': 75
            }, 1000, 'easeInOutExpo');
            
            setTimeout(function () {
                cart.effect("shake", {
                    times: 2
                }, 200);
            }, 1500);

            imgclone.animate({
                'width': 0,
                    'height': 0
            }, function () {
                $(this).detach()
            });
        }
    });  



    // hot picks

// $(document).ready(function(){

// $('.items').slick({
// infinite: true,
// slidesToShow: 4,
// slidesToScroll: 4,
// });
// });

// $('.items').slick({
//   dots: true,
//   infinite: false,
//   speed: 300,
//   slidesToShow: 4,
//   slidesToScroll: 4,
//   responsive: [
//     {
//       breakpoint: 1024,
//       settings: {
//         slidesToShow: 3,
//         slidesToScroll: 3,
//         infinite: true,
//         dots: true
//       }
//     },
//     {
//       breakpoint: 600,
//       settings: {
//         slidesToShow: 2,
//         slidesToScroll: 2
//       }
//     },
//     {
//       breakpoint: 480,
//       settings: {
//         slidesToShow: 1,
//         slidesToScroll: 1
//       }
//     }
  
//   ]
// });


$(document).ready(function(){
    $('.customer-logos').slick({
        slidesToShow: 6,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 1500,
        arrows: false,
        dots: false,
        pauseOnHover: true,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 4
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 3
            }
        }]
    });
});

function change_image(image){
var image_container = document.getElementById("main-image");


image_container.src = image.src;

}

           


         


 
















